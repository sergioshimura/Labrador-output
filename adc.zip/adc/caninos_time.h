
#ifndef __CANINOS_TIME_H

#define __CANINOS_TIME_H

#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>  

#endif


int msleep(long msec);
void delay (unsigned int howLong);
